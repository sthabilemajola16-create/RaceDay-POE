# RaceDay Part 2 — spoken video script

Use this as a cue card. Talk normally. Pause while you click.

Demo password for the seeded accounts: **Password1!**

- Organiser: `thabo.organiser@raceday.co.za`
- Participant: `lerato.runner@email.com`

Swagger: `https://localhost:7188/swagger`

---

**Intro**

Hi, I’m Andiswa Majola, student number ST10486077. This is Part 2 of RaceDay — the ASP.NET Core Web API that runs the whole system. I’ll show the code, Swagger, login for both roles, and the unit tests.

**Structure**

On GitHub, Part 1 docs sit next to the API. SQL and the ERD are in `docs`. The API is in `src/RaceDay.Api`. Tests are in `tests`. Entity Framework is code-first and it matches the eight tables from Part 1. I didn’t invent a second schema.

Auth lives in `AuthController` and `SessionAuthorize`. Login writes user ID and role into a server-side session. Controllers check that before they do anything.

**Auth in Swagger**

I’m in Swagger. Register asks for personal details and a role — Organiser or Participant. The password is hashed. It never comes back in the JSON.

I’ll log in as Thabo, the organiser. After login I call `GET /api/auth/session`. That shows the server stored my user ID and the Organiser role in a session cookie — not a token I copy and paste.

If I call a protected route with no cookie, I get 401. If I stay logged in as a participant and try to create an event, I get 403. Same the other way: an organiser cannot enrol as a runner.

**Organiser**

Still as organiser: create an event — name, description, date, venue, and type: run, walk or cycle. Add a category, like 10 km or Under 20. After people enter, I can see enrolments on my event and type in finish time and position.

**Participant**

Log out, log in as Lerato. I can see events and categories, then enrol by picking a category. The row stores me, the event and the category, plus a bib number. I can only see my own results.

**Tests and CI**

I’ll run `dotnet test` — nineteen tests, all passing: register, login, event CRUD, wrong-role 403s, and enrolment actually written to the database. GitHub Actions does the same build and tests on every push. Here’s the green run.

**Close**

That’s RaceDay Part 2: session auth, both roles, full endpoints in Swagger, tests green locally and on CI. Thank you.

---

## Click order while you talk

1. README + folder tree
2. `docs/RaceDay.sql` or SSMS tables
3. `docs/api-endpoint-plan.md` beside Swagger
4. `POST /api/auth/login` (Thabo)
5. `GET /api/auth/session`
6. `POST /api/events` then `POST /api/events/{id}/categories`
7. `POST /api/enrolments` as organiser → 403
8. logout, login as Lerato
9. `POST /api/enrolments` then `GET /api/enrolments/me`
10. `POST /api/events` as participant → 403
11. private window: `GET /api/users/me` → 401
12. terminal: `dotnet test`
13. GitHub Actions green run
