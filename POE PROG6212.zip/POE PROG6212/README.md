# RaceDay — PROG6212 POE

**Student:** Andiswa Sthabile Majola  
**Student number:** ST10486077  
**Module:** PROG6212 – Programming 2B  

RaceDay is a small South African road-event system. Clubs put on runs, walks and cycle sportives. People enrol online instead of filling in a paper form on the morning.

This repository holds **Part 1** (ERD, SQL script, endpoint plan) and **Part 2** (ASP.NET Core Web API, Entity Framework Core, session auth, Swagger, xUnit tests, GitHub Actions).

**Unlisted demo video:**  
[https://youtu.be/REPLACE_WITH_YOUR_UNLISTED_VIDEO](https://youtu.be/REPLACE_WITH_YOUR_UNLISTED_VIDEO)

A spoken walkthrough for that recording is in `docs/demo-video-script.md`. Paste the real unlisted URL here before ARC handover.

---

## What is in this repo

| Artefact | Where it is |
|---|---|
| Entity relationship diagram (written up) | `docs/erd.md` |
| ERD image for ARC | `docs/erd.png` (export from `ST10486077_ERD.drawio` if the PNG is missing) |
| SQL Server script — database, keys, checks, seed data | `docs/RaceDay.sql` |
| REST endpoint plan (`/api/…`, roles, bodies, responses) | `docs/api-endpoint-plan.md` |
| ASP.NET Core Web API (code-first EF Core) | `src/RaceDay.Api/` |
| xUnit tests | `tests/RaceDay.Api.Tests/` |
| GitHub Actions CI/CD | `.github/workflows/ci.yml` |

`docs/erd.md`, `docs/RaceDay.sql` and the C# entities use the **same eight table names, keys and relationships**. I did not keep a pretty diagram that disagrees with the script.

---

## The two roles

There is no admin super-user. SQL and the API only allow `Organiser` or `Participant`. After login a **server-side session** stores the user’s ID and role. The cookie is HTTP-only. Passwords are hashed with ASP.NET Identity’s hasher and stored in `PasswordHash` only.

### Organiser

This is the person who owns a race weekend. They can:

- create, update and delete **their own** events (name, description, date, venue / city / province, run–walk–cycle type)
- add age or distance **categories** (Under 20, Senior, 10 km, 21.1 km, and so on)
- see every **enrolment** on those events
- type in **finish times and positions** after the chute
- keep route notes and a weather snapshot for race-day prep
- view and update their own profile

They cannot enrol themselves through `POST /api/enrolments`. That returns **403 Forbidden**.

### Participant

This is the runner, walker or cyclist. They can:

- browse events and categories
- **enrol** by picking one category on an event (the row stores participant + event + category, plus a bib number)
- see **their own** enrolments and **their own** results
- update their profile (name, phone, club, date of birth — not their role)

They cannot create events, edit categories, or capture results. Those calls also return **403**.

### What stays public

Register, login, the event list, categories on an event, published results, route notes, weather, and the club drop-down. Everything else needs a session cookie. Missing cookie → **401**. Wrong role → **403**.

The full “who can do what” table is in `docs/api-endpoint-plan.md`.

---

## Folder structure

```
POE PROG6212/
├── README.md
├── RaceDay.sln
├── SQLQuery1_PART1.sql
├── ST10486077_ERD.drawio
├── docs/
│   ├── erd.md
│   ├── erd.png
│   ├── RaceDay.sql
│   ├── api-endpoint-plan.md
│   ├── demo-video-script.md
│   ├── ci-screenshot-instructions.txt
│   └── ci-green-build.png          ← save a real green Actions screenshot here
├── src/RaceDay.Api/                ← Web API, EF Core, session auth, Swagger
├── tests/RaceDay.Api.Tests/        ← xUnit
└── .github/workflows/ci.yml        ← structure checks + build + tests
```

---

## What you need on the machine

- Windows 10/11
- [SQL Server](https://www.microsoft.com/sql-server) (LocalDB, Express or Developer) and **SQL Server Management Studio**
- [.NET 8 SDK](https://dotnet.microsoft.com/download)
- Visual Studio 2022 with the **ASP.NET and web development** workload (or `dotnet` from a terminal)
- Git, and a GitHub account that can push this repo

You do not need Postman. Swagger is how the API is tried in a browser.

---

## Setup and run — database (Part 1)

1. Clone the repository and open the folder that contains `RaceDay.sln`.
2. Open **SQL Server Management Studio** and connect to `(localdb)\MSSQLLocalDB` or `localhost`.
3. Open `docs/RaceDay.sql` (or `SQLQuery1_PART1.sql` — same schema).
4. Press **F5** / Execute.

The script drops `RaceDay` if it is already there, creates it again, builds the eight tables, then inserts sample South African data. If SSMS says the database is in use, close other windows connected to `RaceDay` and run it again.

Quick check:

```sql
USE RaceDay;
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME;
```

You should see `AppUser`, `Category`, `Club`, `Enrolment`, `RaceEvent`, `Result`, `Route`, `WeatherSnapshot`.

The API can also create the database itself on first start (`EnsureCreated` + seed). Running the SQL script first keeps Part 1 and Part 2 on the same schema.

---

## Setup and run — API (Part 2)

1. Open `RaceDay.sln` in Visual Studio 2022.
2. Confirm `src/RaceDay.Api/appsettings.json` points at LocalDB:

   `Server=(localdb)\MSSQLLocalDB;Database=RaceDay;Trusted_Connection=True;TrustServerCertificate=True`

3. Set **RaceDay.Api** as the startup project and press **F5**.
4. Swagger opens at `https://localhost:7188/swagger` (HTTP: `http://localhost:5188/swagger`).
5. Log in (see demo accounts below). Stay in that same browser tab so the session cookie is sent on the next call.
6. Call `GET /api/auth/session` — it should return the logged-in **user ID** and **role**.
7. Try an Organiser route while logged in as a Participant (or the other way around) and confirm **403**.

From a terminal in the folder that contains the solution:

```text
dotnet run --project src/RaceDay.Api
```

Then open `/swagger`.

Every route, body and expected status code is in `docs/api-endpoint-plan.md`. If it is not visible and tryable in Swagger, it is not done.

### Demo accounts (password for all: `Password1!`)

| Role | Email |
|---|---|
| Organiser | `thabo.organiser@raceday.co.za` |
| Organiser | `ayesha.organiser@raceday.co.za` |
| Participant | `lerato.runner@email.com` |
| Participant | `pieter.cyclist@email.com` |

You can also register a new account with `POST /api/auth/register` and set `role` to `Organiser` or `Participant`.

### Suggested Swagger walkthrough

1. `POST /api/auth/login` as Thabo.
2. `GET /api/auth/session` — user ID + `Organiser`.
3. `POST /api/events` — create an event (Running, Walking or Cycling).
4. `POST /api/events/{id}/categories` — e.g. 10 km.
5. `POST /api/enrolments` while still an organiser — expect **403**.
6. `POST /api/auth/logout`, then login as Lerato.
7. `POST /api/enrolments` with `eventId` and `categoryId`.
8. `GET /api/enrolments/me` — participant, event and category on the same row.
9. `POST /api/events` as Lerato — expect **403**.
10. Call `GET /api/users/me` in a private window with no login — expect **401**.

---

## Unit tests

From the folder that contains `RaceDay.sln`:

```text
dotnet test
```

Nineteen tests cover success and failure for:

- registration (Organiser and Participant, hashed password, duplicate email **409**, unknown role **400**)
- login and session (user ID + role stored; wrong password **401**)
- protected route with no cookie **401**, logout then **401**
- organiser create / update / delete of their own event
- participant blocked from creating events and capturing results (**403**)
- organiser blocked from enrolling as a runner (**403**)
- participant enrolment written with participant + event + category (and a bib number)
- second enrolment on the same event **409**; category from another event **400**; anonymous enrol **401**

Those tests must pass on the laptop **and** on GitHub Actions.

---

## GitHub and CI/CD

The workflow is `.github/workflows/ci.yml`. On every push to `main`, `master`, `part-2-api` (and on pull requests) GitHub Actions:

- checks the required folders and files (`docs/`, README, SQL, ERD, endpoint plan, `src/`, `tests/`, the workflow itself)
- greps this README for the two roles, the video link, CI/CD, W3Schools and References
- checks the SQL script creates a database, tables, keys, seed rows, and both roles
- checks the endpoint plan still has HTTP method, `/api/`, role, body, response, register, login, enrolment and results
- restores, builds and runs `dotnet test`

A failing unit test turns the build red.

### Green-build screenshot

After a push shows a green tick on the Actions tab, save that screenshot as `docs/ci-green-build.png` (see `docs/ci-screenshot-instructions.txt`). Do not paste a mocked image.

![GitHub Actions CI/CD — successful green build](docs/ci-green-build.png)

If the picture is missing, the run has not been captured yet. The workflow file is in the repo and will run on the next push.

### How I work on GitHub for this part

- Push from **my own** GitHub account.
- Use a clearly named branch for Part 2 (`part-2-api`).
- Keep **20 or more meaningful commits** for this part (project file, entities, auth/session, each resource, Swagger text, tests, workflow, README, screenshot).
- Do not commit `bin/`, `obj/`, secrets, or a live connection string with a password.

---

## Demo video (unlisted YouTube)

The ARC submission needs an unlisted YouTube video. The recording shows:

1. repo layout and this README
2. the `RaceDay` database (or the SQL script)
3. the endpoint plan next to Swagger
4. register / login as Organiser and as Participant, and `GET /api/auth/session` holding user ID and role
5. create an event, add a category, enrol, capture a result, and the **403**s when the wrong role is used
6. `dotnet test` locally and the green GitHub Actions run

Paste the real unlisted URL at the top of this file before handing in.

---

## References

Fielding, R.T. (2000) *Architectural styles and the design of network-based software architectures*. Doctoral dissertation. University of California, Irvine.

Microsoft (n.d.) *ASP.NET Core fundamentals*. Available at: https://learn.microsoft.com/aspnet/core (Accessed: 15 October 2026).

Sandhu, R.S., Coyne, E.J., Feinstein, H.L. and Youman, C.E. (1996) ‘Role-based access control models’, *IEEE Computer*, 29(2), pp. 38–47.

W3Schools (n.d.a) *HTTP status messages*. Available at: https://www.w3schools.com/tags/ref_httpmessages.asp (Accessed: 14 October 2026).

W3Schools (n.d.b) *SQL primary key*. Available at: https://www.w3schools.com/sql/sql_primarykey.asp (Accessed: 14 October 2026).
