namespace RaceDay.Api.Auth;

public static class SessionKeys
{
    public const string UserId = "UserId";
    public const string Role = "Role";
    public const string Email = "Email";
}
