# RaceDay — PROG6212 POE

**Student:** Andiswa Sthabile Majola  
**Student number:** ST10486077  
**Module:** PROG6212 – Programming 2B  

RaceDay is a small South African road-event system. Clubs put on runs, walks and cycle sportives. People enrol online instead of filling in a paper form on the morning. This repository holds Part 1 (database + API plan) and is the same place Part 2 (the ASP.NET Core Web API) will live, so GitHub Actions can keep checking the folder layout on every push.

**Unlisted demo video (replace this link before ARC handover):**  
[https://youtu.be/REPLACE_WITH_YOUR_UNLISTED_VIDEO](https://youtu.be/REPLACE_WITH_YOUR_UNLISTED_VIDEO)

---

## What I built in Part 1

The brief asked for a real schema, not a sketch. I modelled eight tables so I already have room for clubs, route notes and a weather snapshot, not only users and events.

| Artefact | Where it is |
|---|---|
| Entity relationship diagram (Crow’s foot, written up) | `docs/erd.md` |
| ERD image for ARC | `docs/erd.png` (also `ERD_ST10486077.png` at the repo root) |
| SQL Server script — create database, keys, checks, seed data | `docs/RaceDay.sql` |
| REST endpoint plan (`/api/…`, roles, bodies, responses) | `docs/api-endpoint-plan.md` |
| GitHub Actions workflow | `.github/workflows/ci.yml` |

`docs/erd.md` and `docs/RaceDay.sql` use the **same eight names, keys and relationships**. I did not keep a “pretty” diagram that disagrees with the script.

---

## The two roles

There is no admin super-user. SQL only allows `Organiser` or `Participant`.

### Organiser

This is the person who owns a race weekend. After they register and log in, a **server-side session** stores their user ID and the role `Organiser`. They can:

- create, update and delete **their own** events (name, description, date, venue / city / province, run–walk–cycle type)
- add age or distance **categories** (Under 20, Senior, 10 km, 21.1 km, and so on)
- see every **enrolment** on those events
- type in **finish times and positions** after the chute
- keep route notes and a weather snapshot for race-day prep

They cannot enrol themselves through the participant enrolment route. If they try, the API returns **403 Forbidden**.

### Participant

This is the runner, walker or cyclist. Their session stores user ID and the role `Participant`. They can:

- browse events and categories
- **enrol** by picking one category on an event (the database stores participant + event + category, and a bib number)
- see **their own** enrolments and **their own** results
- update their profile (name, phone, club, date of birth — not their role)

They cannot create events, edit categories, or capture results. Those calls also return **403**.

### What stays public

Register, login, the published event list, categories on an event, published results, route notes, weather, and the club drop-down. Everything else needs a session cookie. No password is stored in plain text — only `PasswordHash`.

A longer “who can do what” table sits in `docs/api-endpoint-plan.md`. That file is the spec I will code against in Part 2 (cookie session, not a JWT printed in Swagger).

---

## Folder structure

```
POE PROG6212/
├── README.md                          ← you are here
├── SQLQuery1_PART1.sql                ← same script kept at the root for SSMS
├── ERD_ST10486077.png
├── ST10486077_ERD.drawio
├── ASSIGN(POE PART1)_ST10486077.pdf
├── docs/
│   ├── erd.md                         ← cardinality and keys
│   ├── erd.png
│   ├── RaceDay.sql                    ← run this in SSMS
│   ├── api-endpoint-plan.md           ← Part 2 specification
│   ├── ci-screenshot-instructions.txt
│   └── ci-green-build.png             ← drop a real green Actions screenshot here
├── .github/workflows/ci.yml           ← CI/CD: structure, SQL and plan checks on every push
└── (Part 2) src/ and tests/           ← ASP.NET Core Web API + xUnit, same repo / Part 2 branch
```

Part 2 will add the C# projects next to these docs so the ERD, SQL and endpoint plan stay the source of truth. I am not inventing a second schema in Entity Framework.

---

## What you need on the machine

- Windows 10/11
- [SQL Server](https://www.microsoft.com/sql-server) (LocalDB, Express or Developer) and **SQL Server Management Studio**
- Git, and a GitHub account that can push this repo
- For Part 2: Visual Studio 2022 (ASP.NET and web development workload) and the .NET SDK that matches the Web API project

You do **not** need extra tools to read the plan. Swagger in Part 2 is how the running API will be tried in a browser.

---

## Setup and run — database (Part 1)

1. Clone the repository and open the folder.
2. Open **SQL Server Management Studio** and connect to your local instance (for many student laptops that is `(localdb)\MSSQLLocalDB` or `localhost`).
3. Open `docs/RaceDay.sql` (or `SQLQuery1_PART1.sql` — they are the same schema).
4. Press **F5** / Execute.

The script drops `RaceDay` if it is already there, creates it again, builds the eight tables with primary keys, foreign keys and check constraints, then inserts sample South African data (KZN Athletics Club, Soweto Sunrise 10 km, Durban Beachfront Half, Stellenbosch Winelands Classic). The last `SELECT` prints row counts so you can see the seed landed.

If SSMS complains that the database is in use, close other query windows connected to `RaceDay` and run the script again. It already sets single-user before the drop.

### Quick check that the schema matches the ERD

After the script:

```sql
USE RaceDay;
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME;
```

You should see `AppUser`, `Category`, `Club`, `Enrolment`, `RaceEvent`, `Result`, `Route`, `WeatherSnapshot`.

---

## Setup and run — API (Part 2)

Part 2 is an ASP.NET Core Web API, code-first Entity Framework Core, **session cookie** auth, Swagger, and xUnit tests. Until those projects are in `src/` this section is the runbook I will follow so the README already has full steps for a marker.

1. Open the solution in Visual Studio 2022.
2. Check `appsettings.json` for a SQL Server connection string that points at the `RaceDay` database (same instance you used above).
3. Apply migrations (or run `docs/RaceDay.sql` first if you are matching Part 1 exactly, then let EF map the existing tables).
4. Set the API project as startup and press **F5**.
5. Open Swagger in the browser (usually `https://localhost:<port>/swagger`).
6. Call `POST /api/auth/register` then `POST /api/auth/login`. The session cookie stays on that tab. After that, try an Organiser route and a Participant route and confirm **403** when the role is wrong.

Every route is listed, with body and expected status codes, in `docs/api-endpoint-plan.md`. If it is not visible and tryable in Swagger, it is not done.

### Unit tests

From the repo root, once the test project exists:

```text
dotnet test
```

Tests must cover, at minimum:

- register and login (happy path and bad password / duplicate email)
- organiser event create/update/delete
- the other role being rejected (**403**)
- a participant enrolment actually writing participant + event + category

Those tests must pass on the laptop **and** on GitHub Actions.

---

## GitHub and CI/CD

The workflow is `.github/workflows/ci.yml`. On every push to `main` / `master` (and on pull requests) GitHub Actions:

- checks the required folders and files are present (`docs/`, README, SQL, ERD, endpoint plan, the workflow itself)
- greps this README for the two roles, the video link, CI/CD, W3Schools and References
- checks the SQL script actually creates a database, tables, keys, seed rows, and both roles
- checks the endpoint plan still has HTTP method, `/api/`, role, body, response, register, login, enrolment and results

Part 2 will extend the same workflow with `dotnet build` and `dotnet test` so a failing unit test turns the build red.

### Green-build screenshot

After a push shows a green tick on the Actions tab, save that screenshot as `docs/ci-green-build.png` (see `docs/ci-screenshot-instructions.txt`). Do not paste a mocked image.

![GitHub Actions CI/CD — successful green build](docs/ci-green-build.png)

If the picture is missing, the run has not been captured yet. The workflow file is still in the repo and will run on the next push.

---

## How I work on GitHub for this part

- Push from **my own** GitHub account.
- Use a clearly named branch or folder for Part 2 when the API code starts (for example `part-2-api`).
- Aim for **20 or more meaningful commits** for Part 2 (project file, entities, auth/session, each resource, Swagger text, tests, workflow, README screenshot).
- Do not commit `bin/`, `obj/`, secrets, or a live connection string with a password.

---

## Demo video (unlisted YouTube)

The ARC submission needs an unlisted YouTube video. In the recording I will:

1. show the repo layout and this README
2. run the SQL script (or show the existing `RaceDay` database)
3. walk the endpoint plan next to Swagger
4. register and log in as Organiser and as Participant, and show the session holding user ID and role
5. create an event, add a category, enrol, capture a result, and show the **403**s when the wrong role is used
6. run the unit tests locally and open the green GitHub Actions run

Paste the real unlisted URL at the top of this file before handing in.

---

## References

Fielding, R.T. (2000) *Architectural styles and the design of network-based software architectures*. Doctoral dissertation. University of California, Irvine.

Microsoft (n.d.) *ASP.NET Core fundamentals*. Available at: https://learn.microsoft.com/aspnet/core (Accessed: 15 October 2026).

Sandhu, R.S., Coyne, E.J., Feinstein, H.L. and Youman, C.E. (1996) ‘Role-based access control models’, *IEEE Computer*, 29(2), pp. 38–47.

W3Schools (n.d.a) *HTTP status messages*. Available at: https://www.w3schools.com/tags/ref_httpmessages.asp (Accessed: 14 October 2026).

W3Schools (n.d.b) *SQL primary key*. Available at: https://www.w3schools.com/sql/sql_primarykey.asp (Accessed: 14 October 2026).
